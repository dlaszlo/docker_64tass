This directory contains exomizer decrunchers in assembly for Intel 8080 contributed by Ivan Gorodetsky (retrocomp@yandex.ru).
Compile with The Telemark Assembler (TASM) 3.2

P43 - size-optimized version
P47T4 - speed-optimized version

P43E - support of shared header/table info for multiple crunched files